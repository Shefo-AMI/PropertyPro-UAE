
import React, { useState, useRef, useEffect } from 'react';
import '../styles/chatwidget.css';

export default function ChatWidget({ apiBase = '/api' }) {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const listRef = useRef();

  useEffect(()=>{ if(listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight; }, [messages, open]);

  async function send(msg) {
    if(!msg.trim()) return;
    setMessages(m=>[...m, {role:'user', text:msg}]);
    setInput('');
    setLoading(true);
    try {
      const res = await fetch(`${apiBase}/assistant`, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ message: msg }) });
      const data = await res.json();
      setMessages(m=>[...m, {role:'assistant', text: data.reply || 'No reply'}]);
    } catch(e) {
      setMessages(m=>[...m, {role:'assistant', text:'Assistant error.'}]);
    } finally { setLoading(false); }
  }

  return (
    <div className={`pm-chat-widget ${open? 'open':''}`} aria-live="polite">
      <div className="pm-chat-fab" onClick={()=>setOpen(!open)} title="Help">AI</div>
      {open && (
        <div className="pm-chat-panel" role="dialog" aria-label="Assistant">
          <div className="pm-chat-header">Assistant <button onClick={()=>setOpen(false)}>×</button></div>
          <div className="pm-chat-list" ref={listRef}>
            {messages.map((m,i)=>(<div key={i} className={`pm-msg ${m.role}`}>{m.text}</div>))}
          </div>
          <form onSubmit={(e)=>{ e.preventDefault(); send(input); }} className="pm-chat-input">
            <input value={input} onChange={e=>setInput(e.target.value)} placeholder="Ask about properties..." />
            <button type="submit" disabled={loading}>Send</button>
          </form>
        </div>
      )}
    </div>
  )
}
