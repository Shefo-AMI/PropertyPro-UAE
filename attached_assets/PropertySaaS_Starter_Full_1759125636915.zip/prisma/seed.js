
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcrypt');
const prisma = new PrismaClient();

async function main() {
  const rawPassword = process.env.DEV_OWNER_PASSWORD || 'ChangeMe123!';
  const passwordHash = await bcrypt.hash(rawPassword, 10);
  console.log('Seeding demo data...');
  const company = await prisma.companies.create({ data: { name: 'Demo Property Co', domain: 'demo.example' } });
  const owner = await prisma.users.create({ data: { company_id: company.id, email: 'owner+demo@example.com', display_name: 'Demo Owner', role: 'owner', password_hash: passwordHash } });
  const property = await prisma.properties.create({ data: { company_id: company.id, name: 'Central Plaza', address: { line1:'123 Main St', city:'Dubai', country:'UAE' }, floors: 12, size_sq_m: 4500 } });
  const unit1 = await prisma.units.create({ data: { property_id: property.id, unit_number: '101', floor: 1, size: 85 } });
  const tenant = await prisma.tenants.create({ data: { company_id: company.id, first_name: 'Ali', last_name: 'Khan', email: 'ali.khan@example.com', phone: '+971500000000' } });
  await prisma.tenancies.create({ data: { tenant_id: tenant.id, unit_id: unit1.id, lease_start: new Date('2025-01-01'), lease_end: new Date('2025-12-31'), rent_amount: 3500, currency: 'AED' } });
  console.log('Seed complete. Owner email:', owner.email, 'password:', rawPassword);
}

main().catch(e=>{ console.error(e); process.exit(1); }).finally(()=>process.exit(0));
