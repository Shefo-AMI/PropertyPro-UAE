
import Head from 'next/head'
import ChatWidget from '../components/ChatWidget'

export default function Home() {
  return (
    <div>
      <Head>
        <title>Property SaaS - Demo</title>
      </Head>
      <div className="container">
        <h1>Property SaaS - Demo Starter</h1>
        <p>This starter includes full schema, assistant endpoint, chat widget, and seed script.</p>
        <ul>
          <li>Companies, Users, Properties, Units, Tenants, Tenancies, Invoices</li>
          <li>Supabase-friendly (use DATABASE_URL or Supabase connection)</li>
          <li>Chat widget (bottom-right)</li>
        </ul>
      </div>
      <ChatWidget apiBase="/api" />
    </div>
  )
}
