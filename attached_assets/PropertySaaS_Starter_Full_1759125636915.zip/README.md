Property SaaS - Full Starter (DoorLoop-like features)

Contents:
- Next.js frontend (pages/)
- API endpoint: pages/api/assistant.js (AI assistant proxy stub)
- Prisma schema: prisma/schema.prisma (full data model)
- Seed script: prisma/seed.js
- Chat widget component: components/ChatWidget.jsx
- GitHub Actions workflow: .github/workflows/deploy.yml (Vercel deploy scaffold)

Quick start:
1. cp .env.example .env -> fill DATABASE_URL and OPENAI_API_KEY and Supabase keys (if using Supabase)
2. npm install
3. npx prisma generate
4. npx prisma migrate dev --name init
5. node prisma/seed.js
6. npm run dev